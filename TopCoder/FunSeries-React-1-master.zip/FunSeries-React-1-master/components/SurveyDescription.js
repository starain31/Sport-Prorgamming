var SurveyDescription = React.createClass({

  render: function () {
    return <p>{this.props.des}</p>
  }
});

module.exports = SurveyDescription;
